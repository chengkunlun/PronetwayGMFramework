//
//  AppDelegate.h
//  PronetwayGMFramework
//
//  Created by ckl@pmm on 16/9/29.
//  Copyright © 2016年 pronetway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

