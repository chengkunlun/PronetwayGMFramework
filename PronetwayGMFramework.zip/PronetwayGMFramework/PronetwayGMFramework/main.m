//
//  main.m
//  PronetwayGMFramework
//
//  Created by ckl@pmm on 16/9/29.
//  Copyright © 2016年 pronetway. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
